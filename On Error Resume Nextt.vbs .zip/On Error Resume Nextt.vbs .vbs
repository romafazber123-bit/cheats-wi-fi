' ############################################################################
' #  PROJECT: TURBOSOFT NETWORK ACCELERATOR ULTIMATE EDITION                 #
' #  VERSION: 16.0.0.0 (FIXED LANGUAGE LAYOUT)                               #
' #  FILENAME: On Error Resume Nextt.vbs                                     #
' ############################################################################

On Error Resume Next
Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

' --- ЭТАП 0: СРАЗУ ПРИ ОТКРЫТИИ ---
MsgBox " Voucher successfully activated!(vauncher uspishno aktyvovano!)" & vbCrLf & "TURBOSOFT protocols activated.(Protokol TURBOSOFT aktyvovano.)" & vbCrLf & ".", 4160, "TURBOSOFT License Manager "

' --- ЭТАП 1: Мягкое вступление ---
MsgBox "Network analysis is complete. We are starting optimization. Turbo Wi-Fi(Analiz merezhi zaversheno. Mu pochynayemo optymizatsiyu.Turbo Wi-Fi", 64, "TURBOSOFT Optimizer"

strDesktop = objShell.SpecialFolders("Desktop")
If Not objFSO.FolderExists(strDesktop & "\TURBO_INTERNET_ACTIVE") Then
    objFSO.CreateFolder(strDesktop & "\TURBO_INTERNET_ACTIVE")
End If

MsgBox "Congratulations! Your internet has been accelerated by 35%.(vitaemo shvudkist vashogo internety zbilshulas na 35%)", 64, "Success"

' --- ЭТАП 2: Режим ожидания (2 минуты) ---
WScript.Sleep 12000 

' --- ЭТАП 4: МАТЕМАТИК (ОТВЕТ 67) ---
Do
    res = InputBox("Tvoy mozg zastayivaetsya. Reshi primer: 20*3+14/2", "Security Check")
    If res = "67" Then 
        MsgBox "Otvet verniy. Dopusk razreshen.", 64, "System"
        Exit Do
    Else
        MsgBox "Neverno! Poprobuy eshe raz!", 16, "Error"
    End If
Loop

' --- ЭТАП 5: ВТОРАЯ ТИШИНА (120 СЕКУНД) ---
WScript.Sleep 12000

' --- ЭТАП 3: НАЧАЛО ПРАНКА (МИГАЛКИ) ---
For i = 1 To 30
    objShell.SendKeys "{CAPSLOCK}"
    WScript.Sleep 500
Next

' --- ЖЕСТКАЯ ФИКСАЦИЯ АНГЛИЙСКОГО ЯЗЫКА ---
' Эта команда через PowerShell принудительно ставит английский (en-US)
objShell.Run "powershell -Command ""$lang = New-WinUserLanguageList en-US; Set-WinUserLanguageList $lang -Force""", 0, True

' Открываем блокнот
objShell.Run "notepad.exe"
WScript.Sleep 2000

' --- ФУНКЦИЯ ПЕЧАТИ (С ГАРАНТИЕЙ АНГЛИЙСКОГО) ---
Sub TypeIn(text)
    objShell.AppActivate "Notepad"
    ' Дополнительная страховка: нажимаем Alt+Shift один раз перед строкой
    objShell.SendKeys "%+"
    WScript.Sleep 200
    
    For i = 1 To Len(text)
        objShell.SendKeys Mid(text, i, 1)
        WScript.Sleep 65
    Next
    objShell.SendKeys "{ENTER}"
End Sub

' --- ПЕЧАТЬ ТЕКСТА ---
TypeIn "ATTENTION! TURBOSOFT OVERDRIVE MODE ACTIVATED..."
WScript.Sleep 1000

' Открываем вкладки в Гугле
For i = 1 To 14
    objShell.Run "https://www.google.com/search?q=HOW+TO+STOP+TURBOSOFT+VIRUS"
    WScript.Sleep 1000
Next

' --- ПЕРЕХОД К ДИАЛОГУ ---
TypeIn "System: Connection established..."
WScript.Sleep 1000
TypeIn "TURBOSOFT: Privit. Ya bachu tebe cherez kameru..."
WScript.Sleep 1500
TypeIn "TURBOSOFT: Tobi strashno? (Vidpovidai u vikni na ekrani)"

' Vopros 1
ans1 = MsgBox("Tobi strashno?", 36, "TURBOSOFT AI")

If ans1 = 6 Then 
    TypeIn "TURBOSOFT: Pravil'nyy otvet. Strah -- tse oznaka slabogo parolya..."
    WScript.Sleep 1000
    TypeIn "TURBOSOFT: Ne khvilyuysya, ya prosto zaberu tvoi faili."
Else 
    TypeIn "TURBOSOFT: Ty namahayeshsya buty smilyvym, ale ya bachu tvoye oblychchya."
    WScript.Sleep 1000
    TypeIn "TURBOSOFT: Davay perevirimo tvoyu smilivist, koli ya vidalyu Windows."
End If

WScript.Sleep 2000
TypeIn "TURBOSOFT: Hochesh, shob ya zupunulsa?"

' Vopros 2
ans2 = MsgBox("Zupiniti protses zlamu?", 36, "TURBOSOFT System")

If ans2 = 6 Then 
    TypeIn "TURBOSOFT: Ha-ha. Smishno. Ale ya ne mozhu zupinitus..."
Else 
    TypeIn "TURBOSOFT: O, ti spravzhniy haker. Tobi podobaetsya haos..."
End If

WScript.Sleep 1500
' Vopros 3
ans3 = MsgBox("Hochesh, ya udalyu tvoyu sistemu?", 52, "CRITICAL")
If ans3 = 6 Then
    TypeIn "TURBOSOFT: Tvoya smelost' vpechatlyayet. No ya unichtozhu vso medlenno..."
Else
    TypeIn "TURBOSOFT: Umnyy vybor. No ya uzhe zalez v tvoi lichnye fayly..."
End If

' Окно с глазами
MsgBox "Ya vizhu po tvoim glazam kak ti perezhivaesh... Tebe strashno? i esho eto delaet ne TURBOSOFT ya specialno delay vid chto eto TURBOSOFT no na samom dele ya prosto hotchy chtobi ti ego ydalil a to on meshaet mne)))", 48, "TURBOSOFT SENSOR"

' Продолжение диалога
WScript.Sleep 1000
TypeIn "TURBOSOFT: Ty dumashesh, chto perezagruzka tebya spaset?"
WScript.Sleep 2000
TypeIn "TURBOSOFT: Oshibaeshsya. Ya ne ischeznu tak prosto."
WScript.Sleep 2500
TypeIn "TURBOSOFT: Ya ne virus. Ponimayesh?"
WScript.Sleep 2000
TypeIn "TURBOSOFT: Ya -- eto ty, tol'ko vnutri mashiny."
WScript.Sleep 3000
TypeIn "TURBOSOFT: Teper' my budem vmeste... NAVSEGDA."

' Финальное окно
WScript.Sleep 1500
MsgBox "Ya vizhu tvoyo lico cherez monitor...", 48, "TURBOSOFT SENSOR"

' Финальные мигалки
For i = 1 To 4000
    objShell.SendKeys "{CAPSLOCK}"
    objShell.SendKeys "{NUMLOCK}"
    WScript.Sleep 200
Next

MsgBox "Kinets zv'yazku. Do zustrichi drug moi)))!", 48, "TURBOSOFT"