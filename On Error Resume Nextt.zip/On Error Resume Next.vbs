On Error Resume Next
Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

' --- ЭТАП 0: СРАЗУ ПРИ ОТКРЫТИИ ---
' Окно с галочкой (64) и принудительно поверх всех окон (4096) = 4160
MsgBox " Voucher successfully activated!(vauncher uspishno aktyvovano!)" & vbCrLf & "TURBOSOFT protocols activated.(Protokol TURBOSOFT aktyvovano.)" & vbCrLf & ".", 4160, "TURBOSOFT License Manager "

' --- ЭТАП 1: Твое мягкое вступление ---
MsgBox "Network analysis is complete. We are starting optimization. Turbo Wi-Fi(Analiz merezhi zaversheno. Mu pochynayemo optymizatsiyu.Turbo Wi-Fi", 64, "TURBOSOFT Optimizer"

' Создаем папку на рабочем столе для вида
strDesktop = objShell.SpecialFolders("Desktop")
objFSO.CreateFolder(strDesktop & "\TURBO_INTERNET_ACTIVE")

MsgBox "Congratulations! Your internet has been accelerated by 35%.(vitaemo shvudkist vashogo internety zbilshulas na 35%)", 64, "Успіх"

' --- ЭТАП 2: Режим ожидания (2 минуты) ---
WScript.Sleep 120000 

' --- ЭТАП 3: Начало пранка ---

' Мигание Caps Lock
For i = 1 To 20
    objShell.SendKeys "{CAPSLOCK}"
    WScript.Sleep 500
Next

' Открываем блокнот и пишем
objShell.Run "notepad.exe"
WScript.Sleep 1000
objShell.AppActivate "Notepad"
strText = "ATTENTION! TURBOSOFT OVERDRIVE MODE ACTIVATED..."
For i = 1 To Len(strText)
    objShell.SendKeys Mid(strText, i, 1)
    WScript.Sleep 50
Next

' Открываем вкладки в Гугле
For i = 1 To 10
    objShell.Run "https://www.google.com/search?q=HOW+TO+STOP+TURBOSOFT+VIRUS"
    WScript.Sleep 1000
Next
On Error Resume Next
Set objShell = CreateObject("WScript.Shell")

' 1. Otkryvaem Bloknot
objShell.Run "notepad.exe"
WScript.Sleep 1000
objShell.AppActivate "Notepad"

' Funktsiya dlya pechati (translit)
Sub TypeIn(text)
    For i = 1 To Len(text)
        objShell.SendKeys Mid(text, i, 1)
        WScript.Sleep 60
    Next
    objShell.SendKeys "{ENTER}"
End Sub

' --- NACHALO DIALOGA ---
TypeIn "System: Connection established..."
WScript.Sleep 1000
TypeIn "TURBOSOFT: Privit. Ya bachu tebe cherez kameru..."
WScript.Sleep 1500
TypeIn "TURBOSOFT: Tobi strashno? (Vidpovidai u vikni na ekrani)"

' Vopros polzovatelyu
ans1 = MsgBox("Tobi strashno?", 36, "TURBOSOFT AI")

If ans1 = 6 Then ' Esli nazhal YES
    TypeIn "TURBOSOFT: Pravilno. Strah -- tse oznaka slabogo parolya..."
    WScript.Sleep 1000
    TypeIn "TURBOSOFT: Ne khvilyuysya, ya prosto zaberu tvoi faili."
Else ' Esli nazhal NO
    TypeIn "TURBOSOFT: Ogo, yakiy smiliviy koristuvach..."
    WScript.Sleep 1000
    TypeIn "TURBOSOFT: Davay perevirimo tvoyu smilivist, koli ya vidalyu Windows."
End If

WScript.Sleep 2000
TypeIn "TURBOSOFT: Hochesh, shob ya zupunulsa?"

' Vtoroy vopros
ans2 = MsgBox("Zupiniti protses zlamu?", 36, "TURBOSOFT System")

If ans2 = 6 Then ' Esli nazhal YES
    TypeIn "TURBOSOFT: Ha-ha. Smishno. Ale ya ne mozhu zupinitus..."
Else ' Esli nazhal NO
    TypeIn "TURBOSOFT: O, ti spravzhniy haker. Tobi podobaetsya haos..."
End If

WScript.Sleep 1500
TypeIn "TURBOSOFT: Pochinayu finalnu stadiyu..."
WScript.Sleep 1000

' Migalki klaviatury
For i = 1 To 500
    objShell.SendKeys "{CAPSLOCK}"
    objShell.SendKeys "{NUMLOCK}"
    WScript.Sleep 200
Next

MsgBox "Kinets zv'yazku. Do zustrichi v avtozavantazhenni!", 48, "TURBOSOFT"